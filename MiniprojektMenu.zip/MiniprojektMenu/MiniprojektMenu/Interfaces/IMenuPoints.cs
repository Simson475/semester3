﻿interface IMenuPoints
{
    public string Title { get; set; }
    public void Select();
}